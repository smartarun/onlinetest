<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<?php //print_r($userdetails); ?>
<div class="container">
<table id="users-table">
    <thead>
        <tr>
		    <th>id</th>
		    <th>Name</th>
		    <th>Email</th>
        </tr>
    </thead>
    <tbody>
        <tr>
		    <td>Alfreds Futterkiste</td>
		    <td>Maria Anders</td>
		    <td>Germany</td>
        </tr>
    </tbody>
</table>
</div>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script>
	$(document).ready(function() {
		//var dataload = '<?php //echo $userdetails ?>';
		//console.log(typeof $.parseJSON(dataload));
		//dataload =  $.parseJSON(dataload);
		//console.log(dataload);

	$('#users-table').DataTable({
		 "processing": true,
        "serverSide": true,
        "ajax": {
        	url:"<?php echo e(route('getuserlist')); ?>"
        },
        //"pageLength": 5,
    //data: dataload,
    columns: [
        { 'data': 'id' },
        { 'data': 'name' },
        { 'data': 'email' }
    ],
});
	} );
/*	$(document).ready(function() {
    $('#users-table').DataTable();
} );*/
</script>
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
