<!doctype html>
<html lang="{{ app()->getLocale() }}">
<h1><b>USER LOGIN</b></h1>
<form method="post" id="domaininput" action="homelogin">
	 {{ csrf_field() }}
	<input type="text" class="form-control" name="name" placeholder="user name" value="" required autofocus>
	<br><br>
	<input type="password" class="form-control" name="password" placeholder="password" value="" required autofocus>
	<br><br>
	<button type="submit">login</button>
</form>
</html>