<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\User;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';
    protected $request;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request)
    {
        $this->middleware('guest')->except('logout');
        $this->request = $request;
    }

    public function index(){
        echo 'test';
    }

        /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function credentials(){
        //print_r($this->request);
        //return view('userlist', ['inputtedkeyword' => $inputtedkeyword->find, 'category' => $blog]);
       // $field = filter_var($this->request->get($this->username()), FILTER_VALIDATE_EMAIL)
           // ? $this->username()
           // : 'username';
         $usercheck = User::select('password')->where('name', $this->request->name)->first();
         if($usercheck){
                if (password_verify($this->request->password, $usercheck->password)) {
                    echo '<b>'.'Welcome back!'.'</b>';
                    exit;
                } else {
                    echo 'Invalid login.';
                    exit;
                }
         } else {
            echo 'Invalid login.';
            exit;
         }
         
        /* return [
            'name' => $this->request->name,
            'password' => $this->request->password,
        ];*/
    }

}
